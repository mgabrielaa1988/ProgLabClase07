#include <stdio.h>
#include <stdlib.h>

#define CANT 5

int main()
{
    int legajo[CANT];
    char nombre[CANT][31];
    float salario[CANT];
    int i;


    for(i=0; i<CANT; i++)
    {
        //printf("Legajo: ");
        legajo[i]=i+1;
        printf("Nombre: ");
        fflush(stdin);
        scanf("%[^\n]",nombre[i]);
        printf("Salario: ");
        scanf("%f",&salario[i]);
    }

    printf("\n\nLegajo\tNombre\tSalario\n");

    for(i=0; i<CANT; i++)
    {
        printf("%d\t%s\t%.2f\n",legajo[i],nombre[i],salario[i]);m�
    }

    return 0;
}
